import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import {DestinationSelectionService } from '../../services/destination-selection.service';

@Component({
  selector: 'app-detail-page',
  templateUrl: './detail-page.component.html',
  styleUrls: ['./detail-page.component.scss']
})
export class DetailPageComponent implements OnInit {
  userFrom: FormGroup;
  modalRef: BsModalRef;
  submitted: any;
  userObject: any;
  disableBtn = false;
  stateDetails: any;
  destinationList: any;
  districts: any;
  dropDownValue;
  stateSelection = new FormControl('');

  constructor(
    private modalService: BsModalService,
    private formBuilder: FormBuilder,
    private destinationService: DestinationSelectionService) { }

  ngOnInit(): void {
    this.getUserData();
  }

getUserData(): void{
  this.userFrom = this.formBuilder.group({
    firstName: ['', Validators.required],
    email: ['', ([
      Validators.required,
      Validators.email
    ])],
    phoneNumber: ['', ([
      Validators.required,
      Validators.minLength(10)
    ])],
    stateSelection : ['', Validators.required],
    destinationSelection: ['', Validators.required]
  });
}

  openmodal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-with-form modal-dialog-centered modal-lg' });
    this.getStatesData();
  }

  getStatesData(){
    this.destinationService.getStatesData().subscribe(response => {
      if (response){
        this.stateDetails = response.data.states_data;
      }
    });
  }

  getItem(id): void{
    this.destinationService.getDestinationData().subscribe(response => {
      this.destinationList = response.data.filter(el => {
        return el.state === id;
      });
      this.districts = this.destinationList[0].districts;
    });
  }

  cancel(): void{
    this.userFrom.reset();
  }
}
