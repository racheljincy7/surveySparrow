import { TestBed } from '@angular/core/testing';

import { DestinationSelectionService } from './destination-selection.service';

describe('DestinationSelectionService', () => {
  let service: DestinationSelectionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DestinationSelectionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
