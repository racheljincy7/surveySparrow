import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DestinationSelectionService {

  constructor(
    public http: HttpClient
  ) { }

  getStatesData(): any {
    return this.http.get('/assets/json/states.json');
  }
  getDestinationData(): any {
    return this.http.get('/assets/json/destination.json');
  }
}
